window.ConstruFactu = window.ConstruFactu || {};
